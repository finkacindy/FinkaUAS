var json_layer0_0 = {
"type": "FeatureCollection",
"name": "layer0_0",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [

]
}
